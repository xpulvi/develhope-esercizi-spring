package co.develhope.demoexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoExerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoExerciseApplication.class, args);
	}

}
