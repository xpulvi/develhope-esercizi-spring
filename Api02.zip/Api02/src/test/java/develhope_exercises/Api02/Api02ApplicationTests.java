package develhope_exercises.Api02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Api02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
