package develhope_exercises.Api02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Api02Application {

	public static void main(String[] args) {
		SpringApplication.run(Api02Application.class, args);
	}

}
